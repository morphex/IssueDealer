# Where indexes are stored, this is Catalog for
# the Issue Dealer, portal_catalog for CMF/Plone
# and so on.

catalog_name = 'Catalog'