class laf_root:

    stop_breadcrumbs = 1
