subscribed = """Subject:  Subscribed to %(title)s

You have been subscribed to the weblog %(title)s
located at %(url)s

To unsubscribe, go to

  %(url)s/subscribe
"""

unsubscribed = """Subject:  Unsubscribed from %(title)s

You have been unsubscribed from the weblog %(title)s
located at %(url)s

To subscribe, go to

  %(url)s/subscribe
"""
