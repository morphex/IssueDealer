import laf_class, laf_property, laf_object

def initialize(context):
    """Initialize the product."""
    pass