#!/bin/sh

#python2.1 tests/testSkeleton.py
python /usr/local/lib/python2.3/FunctionalTests/FTRunner.py functional_tests
