Products.IssueDealer Package Readme
=========================

Overview
--------

The Issue Dealer is an application for managing information. It is currently used by organizations and individuals to manage day-to-day tasks and information.


Your tests here
---------------

    >>> 1 + 1
    3
