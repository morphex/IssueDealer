SKINS_DIR = 'skins'
GLOBALS = globals() 